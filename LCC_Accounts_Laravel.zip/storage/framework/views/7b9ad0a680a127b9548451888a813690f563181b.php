<?php $__currentLoopData = $childs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($child->id); ?>"><?php echo e(str_repeat('-', $level)); ?><?php echo e($child->category_name); ?></option>
        <?php if(count($child->childrens)): ?>
            <?php $level += 1 ?>
            <?php echo $__env->make('pages/transactions/category-child-option', [ 'childs' => $child->childrens, 'level' => $level ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH E:\wampp64\www\lcc_accounts_laravel_midone\resources\views/pages/transactions/category-child-option.blade.php ENDPATH**/ ?>